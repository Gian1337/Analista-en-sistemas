# colors
gris = (100, 100, 100)
azul = (166, 201, 252)
rojo = (200, 0, 0)
blanco = (255, 255, 255)
amarillo = (255, 232, 0)
negro = (0, 0, 0)
verde = (0, 255, 0)