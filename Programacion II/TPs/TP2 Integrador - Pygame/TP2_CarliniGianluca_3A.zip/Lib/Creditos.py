'''
<*************> [Interstellar] <*************>
            Nombre: Interstellar.
            Autor: Carlini, Gianluca.
            Género: Endless.
            Descripción: Videojuego endless por puntajes, llega lo más lejos que puedas esquivando objetos espaciales.
            Version: 1.0
            Asignatura: Programación II.
            Profesor: Vilaboa, Pablo Alfredo.
            Tema: Desarrollo de videojuegos con Pygame.
            Proyecto: Trabajo Práctico Integrador N° 2
'''