'''
Grupo 1
Integrantes: Javier Artale-Giani Carlini
Hernan Ruiz-Maximiliano Falcon Casares
Valentin Wisky
'''
#Ejercicio 1
#1.a Tomando los códigos de cada ítem, ¿cuál sería el resultado que se obtiene por pantalla?
a=100
print(a)
#Rta: 100

#1.b. Ejercicio 2

a=b=c=100
print (a,b,c)
#Rta:100 100 100

#1.c. Ejercicio 3
print ("Hola \n Mundo")
'''Rta:Hola
        Mundo '''

#1.d. Ejercicio 4
print ("Hola","Mundo")
#Rta:Hola Mundo

#1.e. Ejercicio 5
print ("Hola"+"Mundo")
#Rta: HolaMundo

#1.f. Ejercicio 6
print ("la temperatura es", 25, "grados")
#Rta: la temperatura es 25 grados

#1.g. ejercicio 7
print ("Hola %s" % "Mundo")
# Rta: Hola Mundo


#1.i. ejercicio 9
#numeros reales
real= 1.45678
print ("%.2f" % real)
#Rta: 1.46

#1.h. ejercicio 8
print ("La temperatura es %d %s" % (25, "grados"))
#Rta: La temperatura es de 25 grados

#Entradas por teclado
#2- Tomando los códigos de cada ítem, ¿cuál sería el resultado que se obtiene por pantalla?
#a. Ejercicio 1

c= input("dime algo ")
print (c)
#Rta:dime algo

