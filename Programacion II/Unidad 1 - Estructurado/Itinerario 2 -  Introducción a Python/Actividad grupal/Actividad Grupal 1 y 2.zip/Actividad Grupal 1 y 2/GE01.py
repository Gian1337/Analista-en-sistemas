'''
Grupo 1
Integrantes: Gianluca Carlini-Javier Artale-Maximiliano Falcon Casares
Hernan Ruiz-Valentin Wisky

'''
#Ejercicio 2

#2.A

numero = 2

#2.B

texto = "Hola Mundo"

#2.C

''' 
La opción 2nombre no posee un nombre permitido
'''

#2.D

a,b,c = 1,2,3

#2.E

#Error de asignación 

#2.F

edad,nombre = 26,"Pablo"

print("La variable edad toma el siguiente valor:",edad, "y la variable Nombre toma el siguiente valor:",nombre)
#Edad = 26 AND  Nombre = "Pablo"

#2.G

#El tipo de dato que asume la variable luego de ejecutarlo es un INT
a="cadena"
a=23
print(type(a))


#2.H

#No, no está libre de errores.

#2.I

#Los valores A,B y C toman los valores 100.

a=b=c=100
print(a,b,c)

#2.J

#El valor a = 1 y el valor s = 2
a,s=1,2
print(a,s)

